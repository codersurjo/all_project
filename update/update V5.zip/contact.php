<!DOCTYPE HTML>
<html class="no-js" lang="en-US">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Latomio Pyrgon Ltd | Contact Us Today for further Inquiries </title>
        <meta name="description" content="Reach us today if you have any further inquiries or take some time and visit our quarry to meet us directly.">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico" />

		<!-- Stylesheet -->
		<!-- Animate css -->
		<link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="all" />
		<!-- Owl Carousel css -->
		<link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css" media="all" />
		<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css" media="all" />
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<!-- normalize -->
        <link rel="stylesheet" href="assets/css/normalize.css">
        <!-- normalize -->
        <link rel="stylesheet" href="assets/css/aos.css">

        <!-- google Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Michroma&family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
		<!-- Main Stylesheet -->
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- responsive -->
        <link rel="stylesheet" href="assets/css/responsive.css">
    </head>
    <body>
<div class="roadmap" style="overflow: hidden;">
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

<div id="preloader"></div>
        <!-- ------------------ Header area design ------------------ -->
        <div class="header_area_design">
        	<div class="container">
        		<div class="row">
        			<div class="col-xl-12">
        				<div class="main_h">
        				<div class="logo">
        					<a class="laptop" href="#"><img src="assets/images/footer.png"></a>
        					<a class="desktop" href="#"><img src="assets/images/logo.png"></a>

        					<!-- toggle_icon -->
        					<div class="m_icon">
        						<img src="assets/images/menu.png">
        					</div>
        				</div>

        				<div class="header_menu">
        					<ul>
        						<li><a href="index.html">Home</a></li>
        						<li><a href="about.html">About us</a></li>
        						<li><a href="daibase.html">The products</a></li>
        						<li><a href="plant.html">The plant</a></li>
        						<li><a class="active_m" href="contact.html">Contаct us</a></li>
        					</ul>

        					<div class="language">
        						<ul>
        							<li><a class="active_m" href="#">En</a> <span></span> <a href="#">Gr</a></li>
        						</ul>
        					</div>
        				</div>
        				</div>
        			</div>
        		</div>
        	</div>
        </div>


        <!-- ------------------ End Header area design -------------- -->
		
				<!-- ---------- Achivement area design ---------- -->
		<div class="achivement_area_design achivement2_area">
			<div class="container">
				<div class="row">
					<div class="col-xl-12">
						<div class="title_2"  data-aos="fade-up">
							<h2>Contacts</h2>
						</div>
					</div>
				</div>

				<div class="row achive_item">
					<!-- single -->
					<div class="col-md-3 col-6"  data-aos="fade-up">
						<div class="achive_single">
							<h3>Our location</h3>
							<h5>Costa Latourou 10, 2540 Dali, P.O. Box 11112, 2551</h5>
						</div>
					</div>
					<!-- single -->
					<div class="col-md-3 col-6"  data-aos="fade-up">
						<div class="achive_single">
							<h3>Speak to us</h3>
							<h5>+357 22266920 <br>+357 99408788</h5>
						</div>
					</div>
					<!-- single -->
					<div class="col-md-3 col-6"  data-aos="fade-up">
						<div class="achive_single">
							<h3>Our fax number</h3>
							<h5>+357 22266929</h5>
						</div>
					</div>
					<!-- single -->
					<div class="col-md-3 col-6"  data-aos="fade-up">
						<div class="achive_single">
							<h3>Send as an email</h3>
							<h5>latouros@latouros.com <br>achilmen@cytanet.com.cy</h5>
						</div>
					</div>
				</div>

			</div>
		</div>

		<!-- ------------ End Achivement Area design --------- -->

		<!-- ------------- Contact area design ------------ -->
		<div class="contact_area_design">
			<div class="container">

				<div class="row">
					<div class="col-lg-4">
						<h2>FURTHER <br> INQUIRES?</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="con_form">
							<form action="mail.php" method="POST">
								<div class="row">
									<div class="col-lg-4">
										<div class="all_single">
											<!-- single -->
											<div class="input_sin">
												<input type="text" name="name" placeholder="Name" required>
											</div>
											<div class="input_sin">
												<input type="email" name="email" placeholder="Email" required>
											</div>
											<div class="input_sin">
												<input type="text" name="phone" placeholder="phone" required>
											</div>
										</div>
									</div>

									<div class="col-lg-3">
										<div class="all_single">
											<div class="input_sin">
												<textarea name="message"  placeholder="Message" required></textarea>
											</div>
										</div>
									</div>


									<div class="col-lg-12">
										<div class="input_button">
											<input type="submit" value="Contact us today">
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>

			<div class="map">
				<div class="map_image">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10254.099869090118!2d33.44030894283784!3d34.91115733917973!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzTCsDU0JzMwLjAiTiAzM8KwMjYnMjguOSJF!5e0!3m2!1sen!2s!4v1588705854426!5m2!1sen!2s
" tabindex="0"></iframe>
				</div>
			</div>
		</div>

		<!-- --------------- End Contact Area design -------- -->

		<!-- ------------ Footer Area design -------------- -->
		<div class="footer_area_design">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="all_footer">
							<div class="left">
								<a href="#"><img src="assets/images/footer.png"></a>
								<p>Copyrights &copy; 2020 All Rights Reserved. </p>
							</div>

							<div class="middle">
								<a href="#">Website by <a href="https://exeltive.com/"><img src="assets/images/web.png"></a></a>
							</div>

							<div class="right">
								<ul>
	        						<li><a href="index.html">Home</a></li>
	        						<li><a href="about.html">About us</a></li>
	        						<li><a href="daibase.html">The products</a></li>
	        						<li><a href="plant.html">The plant</a></li>
	        						<li><a class="active_m" href="contact.html">Contаct us</a></li>
	        					</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- ----------- End Footer Area design ------------- -->


		<?php if(isset($_GET['success'])): ?>

		<div class="modal fade" id="successMsg" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
		    <div class="modal-content">
		      <div class="modal-body">
		        <div class="alert alert-success">
		        	 <div class="image_area">
		        	 	<img src="assets/images/g.png">
		        	 	<h2>Message delivered</h2>
		        	 </div>
		        </div>
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
		      </div>
		    </div>
		  </div>
		</div>
		
		<?php endif; ?>
</div>
		
		<!-- Js Files -->
		<!-- modernizr -->
        <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
		<!-- jQuery -->
        <script src="assets/js/vendor/jquery-3.2.1.min.js"></script>
		<!-- Bootstrap Popper -->
        <script src="assets/js/popper.js"></script>
		<!-- Bootstrap -->
        <script src="assets/js/bootstrap.min.js"></script>
         <!-- Lightbox js -->
        <script src="assets/js/lightboxcss.js"></script>
        <script src="assets/js/lightbox.js"></script>
		<!-- Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- AOS  JS -->
        <script src="assets/js/aos.js"></script>
         <!-- Ajax js -->
        <script src="assets/js/ajax mail.js"></script>
		<!-- Custom Scripts -->
        <script src="assets/js/main.js"></script>
        <script>
        	AOS.init({
			  offset: 200,
			  // duration: 1000,
			  delay: 50,
			  once: true
			});
			$('#successMsg').modal('show');
        </script>
        
    </body>
</html>
